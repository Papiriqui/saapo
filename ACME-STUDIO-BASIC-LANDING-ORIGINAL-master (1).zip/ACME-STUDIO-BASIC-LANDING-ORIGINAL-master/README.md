# ACME.studio Landing Page: FAST FIT
Nuestro esta elaborado para sustentar 2 segmentos objetivos que ayuda a las personas vulnerables de acoso sexual o bullying

Misión:

Nuestra empresa busca crear una aplicación tecnológica que permita conectar de manera rápida y efectiva a usuarios que necesiten de una ayuda psicológica, para que de esa manera puedan recibir ayuda inmediata por psicólogos expertos en su área y altamente calificados.

Visión:

Nuestra meta es brindar soluciones eficaces a los usuarios que buscan un soporte psicológico especializado mediante sus aplicativos móviles, logrando reducir la gran cantidad porcentual de personas que sufren problemas sociales en el Perú, para un futuro mejor a nivel nacional.

SEGMENTOS OBJETIVOS:

1.Personas vulnerables que sufren acoso sexual o bullying

2.Especialistas en el area de psicologia

DESCRIPCION DE LA APLICACION

1.Contiene una interfaz de diseño interactivo

2.Accesible ante cualquier usuario que desee recibir atencion

3.Facil uso y entendimiento

4.Brinda beneficios gratuitos para el desarrollo del usuario

5.Brinda planes y subscripciones gratuitas
